@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-and-build.ps1"
echo.
pause
