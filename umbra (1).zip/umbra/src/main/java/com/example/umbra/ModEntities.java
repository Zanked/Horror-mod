package com.example.umbra;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, Umbra.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<ShadowEntity>> SHADOW = ENTITIES.register("shadow",
            () -> EntityType.Builder.of(ShadowEntity::new, MobCategory.MISC)
                    .sized(0.6F, 2.1F)
                    .clientTrackingRange(8)
                    .fireImmune()
                    .noSave()
                    .build("shadow"));

    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(SHADOW.get(), ShadowEntity.createAttributes().build());
    }
}
