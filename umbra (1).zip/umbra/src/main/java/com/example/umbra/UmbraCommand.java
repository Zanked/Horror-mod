package com.example.umbra;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/** Debug commands: /umbra shadow | steps | sound  (op only) */
@EventBusSubscriber(modid = Umbra.MODID)
public class UmbraCommand {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("umbra")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("shadow").executes(ctx -> run(ctx, HorrorDirector.Kind.SHADOW)))
                .then(Commands.literal("steps").executes(ctx -> run(ctx, HorrorDirector.Kind.FOOTSTEPS)))
                .then(Commands.literal("sound").executes(ctx -> run(ctx, HorrorDirector.Kind.SOUND))));
    }

    private static int run(CommandContext<CommandSourceStack> ctx, HorrorDirector.Kind kind) throws CommandSyntaxException {
        ServerPlayer player = ctx.getSource().getPlayerOrException();
        boolean ok = HorrorDirector.trigger(player, kind);
        String text = ok ? "Triggered: " + kind.name().toLowerCase()
                : "Could not trigger " + kind.name().toLowerCase() + " here (no valid spot, or one already exists)";
        ctx.getSource().sendSuccess(() -> Component.literal(text), false);
        return ok ? 1 : 0;
    }
}
