package com.example.umbra;

import java.util.concurrent.ThreadLocalRandom;

import net.neoforged.neoforge.common.ModConfigSpec;

public class Config {
    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    public static final ModConfigSpec.BooleanValue ENABLED = BUILDER
            .comment("Master switch for all horror events")
            .define("enabled", true);

    public static final ModConfigSpec.IntValue MIN_COOLDOWN = BUILDER
            .comment("Minimum seconds between events for one player")
            .defineInRange("minCooldownSeconds", 90, 5, 36000);

    public static final ModConfigSpec.IntValue MAX_COOLDOWN = BUILDER
            .comment("Maximum seconds between events for one player")
            .defineInRange("maxCooldownSeconds", 300, 5, 36000);

    public static final ModConfigSpec.IntValue TENSION_THRESHOLD = BUILDER
            .comment("Tension (0-100) needed before events can happen. Tension grows in darkness, at night and underground, and drops near light")
            .defineInRange("tensionThreshold", 30, 0, 100);

    public static final ModConfigSpec SPEC = BUILDER.build();

    public static int randomCooldown() {
        int min = MIN_COOLDOWN.get();
        int max = Math.max(min, MAX_COOLDOWN.get());
        return min + ThreadLocalRandom.current().nextInt(max - min + 1);
    }
}
