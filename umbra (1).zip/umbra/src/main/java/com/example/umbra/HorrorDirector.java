package com.example.umbra;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Decides when something creepy happens to a player.
 *
 * Tension (0-100) per player: grows in darkness, at night and underground, drops near light.
 * When tension is high enough and the cooldown is over, a random event fires:
 *  - SHADOW: a faceless shadow appears far away in the player's view
 *  - FOOTSTEPS: steps behind the player that only play while the player is walking
 *  - SOUND: a distant door/chest sound
 */
@EventBusSubscriber(modid = Umbra.MODID)
public class HorrorDirector {

    public enum Kind { SHADOW, FOOTSTEPS, SOUND }

    private static final Map<UUID, PlayerState> STATES = new HashMap<>();

    private static class PlayerState {
        float tension;
        int cooldownSeconds = Config.randomCooldown();
        UUID shadowId;
        int stepsLeft;
        int stepWindow;
        double stepAccum;
        double lastX;
        double lastZ;
        boolean hasLast;
    }

    // ------------------------------------------------------------------ events

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        if (!Config.ENABLED.get() || player.isSpectator()) {
            return;
        }
        ServerLevel level = player.serverLevel();
        PlayerState st = STATES.computeIfAbsent(player.getUUID(), id -> new PlayerState());

        tickFootsteps(player, level, st);

        if (level.dimension() != Level.OVERWORLD || player.tickCount % 20 != 0) {
            return;
        }

        updateTension(player, level, st);
        st.cooldownSeconds--;
        if (st.cooldownSeconds > 0 || st.tension < Config.TENSION_THRESHOLD.get()) {
            return;
        }

        // the longer the world lives, the more likely events become
        double days = level.getDayTime() / 24000.0D;
        double dayFactor = Math.min(1.0D, 0.25D + days * 0.075D);
        if (level.random.nextDouble() > 0.1D * dayFactor) {
            return;
        }

        int roll = level.random.nextInt(100);
        Kind kind = roll < 40 ? Kind.SHADOW : roll < 70 ? Kind.FOOTSTEPS : Kind.SOUND;
        if (!trigger(player, kind)) {
            trigger(player, Kind.SOUND);
        }
        st.cooldownSeconds = Config.randomCooldown();
        st.tension = Math.max(0.0F, st.tension - 40.0F);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        STATES.remove(event.getEntity().getUUID());
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        STATES.clear();
    }

    // ------------------------------------------------------------------ tension

    private static void updateTension(ServerPlayer player, ServerLevel level, PlayerState st) {
        BlockPos pos = player.blockPosition();
        int light = level.getMaxLocalRawBrightness(pos);
        boolean sky = level.canSeeSky(pos);

        float delta = 0.0F;
        if (light <= 4) {
            delta += 1.5F;
        } else if (light <= 7) {
            delta += 0.5F;
        }
        if (level.isNight()) {
            delta += 0.6F;
        }
        if (!sky && pos.getY() < level.getSeaLevel()) {
            delta += 0.4F;
        }
        if (light >= 12) {
            delta -= 2.5F;
        } else if (light >= 9) {
            delta -= 1.0F;
        }
        st.tension = Mth.clamp(st.tension + delta, 0.0F, 100.0F);
    }

    // ------------------------------------------------------------------ triggering

    /** Fires an event right now (used by the random director and by /umbra). Returns false if it could not happen. */
    public static boolean trigger(ServerPlayer player, Kind kind) {
        ServerLevel level = player.serverLevel();
        PlayerState st = STATES.computeIfAbsent(player.getUUID(), id -> new PlayerState());
        return switch (kind) {
            case SHADOW -> spawnShadow(player, level, st);
            case FOOTSTEPS -> {
                st.stepsLeft = 6 + level.random.nextInt(7);
                st.stepWindow = 20 * 60;
                st.stepAccum = 0.0D;
                yield true;
            }
            case SOUND -> distantSound(player, level);
        };
    }

    // ------------------------------------------------------------------ shadow

    private static boolean spawnShadow(ServerPlayer player, ServerLevel level, PlayerState st) {
        if (st.shadowId != null) {
            Entity old = level.getEntity(st.shadowId);
            if (old != null && old.isAlive()) {
                return false;
            }
            st.shadowId = null;
        }

        RandomSource rnd = level.random;
        Vec3 eye = player.getEyePosition();
        boolean underground = !level.canSeeSky(player.blockPosition());

        for (int i = 0; i < 20; i++) {
            double angle = Math.toRadians(player.getYRot()) + (rnd.nextDouble() * 2.0D - 1.0D) * Math.toRadians(70.0D);
            double dist = underground ? 12.0D + rnd.nextDouble() * 10.0D : 22.0D + rnd.nextDouble() * 16.0D;
            double x = player.getX() - Math.sin(angle) * dist;
            double z = player.getZ() + Math.cos(angle) * dist;

            BlockPos spot = findFloor(level, x, player.getY(), z);
            if (spot == null || level.getMaxLocalRawBrightness(spot) > 9) {
                continue;
            }

            Vec3 shadowEye = new Vec3(spot.getX() + 0.5D, spot.getY() + 1.8D, spot.getZ() + 0.5D);
            BlockHitResult hit = level.clip(new ClipContext(eye, shadowEye,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (hit.getType() != HitResult.Type.MISS) {
                continue;
            }

            ShadowEntity shadow = ModEntities.SHADOW.get().create(level);
            if (shadow == null) {
                return false;
            }
            double cx = spot.getX() + 0.5D;
            double cz = spot.getZ() + 0.5D;
            float yaw = (float) (Mth.atan2(player.getZ() - cz, player.getX() - cx) * (180.0D / Math.PI)) - 90.0F;
            shadow.moveTo(cx, spot.getY(), cz, yaw, 0.0F);
            shadow.setYHeadRot(yaw);
            shadow.setYBodyRot(yaw);
            level.addFreshEntity(shadow);
            st.shadowId = shadow.getUUID();
            return true;
        }
        return false;
    }

    private static BlockPos findFloor(ServerLevel level, double x, double refY, double z) {
        int bx = Mth.floor(x);
        int bz = Mth.floor(z);
        int baseY = Mth.floor(refY);
        if (!level.hasChunkAt(new BlockPos(bx, baseY, bz))) {
            return null;
        }
        for (int y = baseY + 4; y >= baseY - 8; y--) {
            BlockPos pos = new BlockPos(bx, y, bz);
            BlockPos below = pos.below();
            if (level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)
                    && level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()
                    && level.getBlockState(pos.above()).getCollisionShape(level, pos.above()).isEmpty()
                    && level.getBlockState(pos.above(2)).getCollisionShape(level, pos.above(2)).isEmpty()) {
                return pos;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ footsteps

    private static void tickFootsteps(ServerPlayer player, ServerLevel level, PlayerState st) {
        double dx = player.getX() - st.lastX;
        double dz = player.getZ() - st.lastZ;
        double moved = st.hasLast ? Math.sqrt(dx * dx + dz * dz) : 0.0D;
        st.lastX = player.getX();
        st.lastZ = player.getZ();
        st.hasLast = true;

        if (st.stepsLeft <= 0) {
            return;
        }
        if (--st.stepWindow <= 0) {
            st.stepsLeft = 0;
            return;
        }
        // steps only follow the player while they walk; silence when they stop
        if (moved < 0.03D || moved > 2.0D) {
            return;
        }
        st.stepAccum += moved;
        if (st.stepAccum < 0.85D) {
            return;
        }
        st.stepAccum = 0.0D;

        Vec3 look = player.getLookAngle();
        Vec3 back = new Vec3(-look.x, 0.0D, -look.z);
        if (back.lengthSqr() < 1.0E-4D) {
            return;
        }
        back = back.normalize();

        // each step is a bit closer than the previous one
        double dist = 4.0D + st.stepsLeft * 0.6D;
        double x = player.getX() + back.x * dist;
        double z = player.getZ() + back.z * dist;
        BlockPos floor = findFloor(level, x, player.getY(), z);
        st.stepsLeft--;
        if (floor == null) {
            return;
        }

        SoundEvent step = level.getBlockState(floor.below()).getSoundType().getStepSound();
        float pitch = 0.8F + level.random.nextFloat() * 0.2F;
        playFor(player, step, x, floor.getY(), z, 0.9F, pitch);
    }

    // ------------------------------------------------------------------ distant sounds

    private static final SoundEvent[] DISTANT_SOUNDS = {
            SoundEvents.WOODEN_DOOR_OPEN,
            SoundEvents.WOODEN_DOOR_CLOSE,
            SoundEvents.WOODEN_TRAPDOOR_CLOSE,
            SoundEvents.CHEST_OPEN
    };

    private static boolean distantSound(ServerPlayer player, ServerLevel level) {
        RandomSource rnd = level.random;
        double angle = rnd.nextDouble() * Math.PI * 2.0D;
        double dist = 10.0D + rnd.nextDouble() * 12.0D;
        SoundEvent sound = DISTANT_SOUNDS[rnd.nextInt(DISTANT_SOUNDS.length)];
        playFor(player, sound,
                player.getX() + Math.cos(angle) * dist, player.getY(), player.getZ() + Math.sin(angle) * dist,
                1.6F, 0.75F + rnd.nextFloat() * 0.3F);
        return true;
    }

    // ------------------------------------------------------------------ helpers

    /** Plays a sound only for this player. */
    private static void playFor(ServerPlayer player, SoundEvent sound, double x, double y, double z, float volume, float pitch) {
        player.connection.send(new ClientboundSoundPacket(
                BuiltInRegistries.SOUND_EVENT.wrapAsHolder(sound),
                SoundSource.AMBIENT, x, y, z, volume, pitch, player.getRandom().nextLong()));
    }
}
