package com.example.umbra;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * A faceless shadow. It never attacks, never moves and never takes damage.
 * It stands far away, disappears if looked at for too long, or if the player comes close.
 */
public class ShadowEntity extends Mob {
    private static final int MAX_AGE = 20 * 45;          // lives at most 45 s
    private static final int LOOK_LIMIT = 40;            // ticks of being looked at before vanishing (2 s)
    private static final double CLOSE_DISTANCE = 9.0;    // vanishes if the player gets closer than this

    private int age;
    private int lookTicks;

    public ShadowEntity(EntityType<? extends ShadowEntity> type, Level level) {
        super(type, level);
        this.setNoAi(true);
        this.setSilent(true);
        this.setPersistenceRequired();
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 1.0D);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        this.age++;

        Player player = this.level().getNearestPlayer(this, 64.0D);
        if (player == null || this.age > MAX_AGE) {
            this.vanish(false);
            return;
        }

        if (this.distanceToSqr(player) < CLOSE_DISTANCE * CLOSE_DISTANCE) {
            this.vanish(true);
            return;
        }

        if (this.isLookedAtBy(player)) {
            if (++this.lookTicks >= LOOK_LIMIT) {
                this.vanish(true);
            }
        } else if (this.lookTicks > 0) {
            this.lookTicks--;
        }
    }

    private boolean isLookedAtBy(Player player) {
        Vec3 view = player.getViewVector(1.0F);
        Vec3 toMe = new Vec3(
                this.getX() - player.getX(),
                this.getEyeY() - player.getEyeY(),
                this.getZ() - player.getZ());
        double len = toMe.length();
        if (len < 1.0E-6D) {
            return true;
        }
        toMe = toMe.scale(1.0D / len);
        return view.dot(toMe) > 0.96D && player.hasLineOfSight(this);
    }

    private void vanish(boolean withEffects) {
        if (withEffects && this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.LARGE_SMOKE,
                    this.getX(), this.getY() + 1.0D, this.getZ(), 12, 0.25D, 0.8D, 0.25D, 0.01D);
            serverLevel.playSound(null, this.getX(), this.getY(), this.getZ(),
                    SoundEvents.REDSTONE_TORCH_BURNOUT, SoundSource.AMBIENT, 0.4F, 0.6F);
        }
        this.discard();
    }

    // --- The shadow cannot be hurt, pushed or targeted (except by /kill) ---

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) && super.hurt(source, amount);
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }
}
