package com.example.umbra;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ShadowRenderer extends MobRenderer<ShadowEntity, HumanoidModel<ShadowEntity>> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(Umbra.MODID, "textures/entity/shadow.png");

    public ShadowRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.0F);
    }

    @Override
    public ResourceLocation getTextureLocation(ShadowEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(ShadowEntity entity, PoseStack poseStack, float partialTickTime) {
        // taller and thinner than a player
        poseStack.scale(0.95F, 1.15F, 0.95F);
    }
}
