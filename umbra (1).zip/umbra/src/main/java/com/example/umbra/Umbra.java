package com.example.umbra;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;

@Mod(Umbra.MODID)
public class Umbra {
    public static final String MODID = "umbra";

    public Umbra(IEventBus modEventBus, ModContainer modContainer) {
        ModEntities.ENTITIES.register(modEventBus);
        modEventBus.addListener(ModEntities::onAttributes);
        modContainer.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }
}
