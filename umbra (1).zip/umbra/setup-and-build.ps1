# Umbra: one-click setup + build (Windows PowerShell)
# 1) downloads the official NeoForge MDK for 1.21.1 and takes the Gradle wrapper + current versions from it
# 2) builds the mod
# 3) copies the finished jar to the "dist" folder
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
    Write-Host "Java not found. Install JDK 21 (https://adoptium.net, Temurin 21) and run this again." -ForegroundColor Red
    exit 1
}

if (-not (Test-Path .\gradlew.bat)) {
    Write-Host "Downloading NeoForge MDK (1.21.1)..."
    $tmp = Join-Path $env:TEMP "neoforge-mdk-umbra"
    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
    New-Item -ItemType Directory $tmp | Out-Null
    $zip = Join-Path $tmp "mdk.zip"
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -Uri "https://github.com/neoforged/MDK/archive/refs/heads/1.21.1.zip" -OutFile $zip
    Expand-Archive $zip -DestinationPath $tmp
    $mdk = Get-ChildItem $tmp -Directory | Select-Object -First 1

    Copy-Item (Join-Path $mdk.FullName "gradlew") .
    Copy-Item (Join-Path $mdk.FullName "gradlew.bat") .
    Copy-Item (Join-Path $mdk.FullName "gradle") . -Recurse

    # take plugin and NeoForge versions from the MDK so they always resolve
    $utf8 = New-Object System.Text.UTF8Encoding $false
    $mdkBuild = Get-Content (Join-Path $mdk.FullName "build.gradle") -Raw
    if ($mdkBuild -match "net\.neoforged\.moddev'\s+version\s+'([^']+)'") {
        $plugin = $Matches[1]
        $path = (Resolve-Path .\build.gradle).Path
        $text = [IO.File]::ReadAllText($path)
        $text = $text -replace "(net\.neoforged\.moddev'\s+version\s+')[^']+(')", ('${1}' + $plugin + '${2}')
        [IO.File]::WriteAllText($path, $text, $utf8)
        Write-Host "moddev plugin version: $plugin"
    }
    $mdkProps = Get-Content (Join-Path $mdk.FullName "gradle.properties") -Raw
    if ($mdkProps -match "(?m)^neo_version=(\S+)") {
        $neo = $Matches[1]
        $path = (Resolve-Path .\gradle.properties).Path
        $text = [IO.File]::ReadAllText($path)
        $text = $text -replace "(?m)^neo_version=.*$", ("neo_version=" + $neo)
        [IO.File]::WriteAllText($path, $text, $utf8)
        Write-Host "NeoForge version: $neo"
    }
}

Write-Host "Building..."
& .\gradlew.bat build
if ($LASTEXITCODE -ne 0) {
    Write-Host "Build failed. Copy the error text and send it to me." -ForegroundColor Red
    exit 1
}

New-Item -ItemType Directory dist -Force | Out-Null
Copy-Item .\build\libs\*.jar .\dist\ -Force
Write-Host ""
Write-Host "Done! The jar is in the 'dist' folder. Put it into .minecraft\mods (NeoForge 1.21.1)." -ForegroundColor Green
