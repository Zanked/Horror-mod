# Umbra (working title)

Atmospheric horror mod for Minecraft 1.21.1 / NeoForge. No blocks — only a faceless Shadow entity and subtle events.

## Build on GitHub (no local setup)
Push this repo to GitHub. The workflow in `.github/workflows/build.yml` builds the jar on every push to `main`:
open the **Actions** tab, pick the latest run, download the **umbra-jar** artifact.
To publish a release, push a tag: `git tag v0.1.0 && git push origin v0.1.0` - the jar is attached to a GitHub Release automatically.

## Quick start (Windows)
1. Install JDK 21 (Temurin 21 from https://adoptium.net).
2. Unzip the archive.
3. Double-click `setup-and-build.bat` - it downloads the Gradle wrapper and current versions from the official MDK (NeoForgeMDKs/MDK-1.21.1-ModDevGradle), builds the mod and puts the jar into `dist/`.
4. Put the jar from `dist/` into `.minecraft/mods` (NeoForge 1.21.1 must be installed).
5. To test directly from the sources instead: double-click `run-client.bat` (after step 3 has been done once).

## Manual setup
Copy `gradlew`, `gradlew.bat` and `gradle/wrapper/` from the NeoForge MDK (NeoForgeMDKs/MDK-1.21.1-ModDevGradle), take the `net.neoforged.moddev` plugin version
and `neo_version` from the MDK too, then run `gradlew build` (jar: `build/libs/`) or `gradlew runClient`.

## Testing in game (op only)
- `/umbra shadow` — spawn the Shadow in view, far away
- `/umbra steps` — footsteps behind you (only while you walk)
- `/umbra sound` — distant door/chest sound

## How it works
- **HorrorDirector** keeps a "tension" value per player (grows in darkness / night / underground, drops near light)
  and fires random events when tension is high and the cooldown is over.
- **ShadowEntity** never attacks or moves; it vanishes after ~2 s of being looked at, when you come within 9 blocks, or after 45 s.
- Timings are in `config/umbra-common.toml`.

## Renaming
Mod id `umbra`, package `com.example.umbra`. To rename: change `mod_id` in gradle.properties,
`Umbra.MODID`, `neoforge.mods.toml`, the `assets/umbra` folder and the package.
