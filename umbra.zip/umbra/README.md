# Umbra (working title)

Atmospheric horror mod for Minecraft 1.21.1 / NeoForge. No blocks — only a faceless Shadow entity and subtle events.

## Setup
1. Copy the Gradle wrapper into this folder (`gradlew`, `gradlew.bat`, `gradle/wrapper/`) from the official NeoForge MDK
   (https://github.com/neoforged/MDK, branch for 1.21.1), or run `gradle wrapper --gradle-version 8.10.2`.
2. If the `net.neoforged.moddev` plugin version in `build.gradle` or `neo_version` in `gradle.properties` doesn't resolve,
   take the current ones from the MDK.
3. `./gradlew runClient` to test, `./gradlew build` to get the jar in `build/libs/`.

## Testing in game (op only)
- `/umbra shadow` — spawn the Shadow in view, far away
- `/umbra steps` — footsteps behind you (only while you walk)
- `/umbra sound` — distant door/chest sound

## How it works
- **HorrorDirector** keeps a "tension" value per player (grows in darkness / night / underground, drops near light)
  and fires random events when tension is high and the cooldown is over.
- **ShadowEntity** never attacks or moves; it vanishes after ~2 s of being looked at, when you come within 9 blocks, or after 45 s.
- Timings are in `config/umbra-common.toml`.

## Renaming
Mod id `umbra`, package `com.example.umbra`. To rename: change `mod_id` in gradle.properties,
`Umbra.MODID`, `neoforge.mods.toml`, the `assets/umbra` folder and the package.
